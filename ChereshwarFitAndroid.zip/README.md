# Chereshwar.Fit Android App

This Android Studio project wraps the live Chereshwar.Fit website:

https://incomparable-hummingbird-bfda77.netlify.app/

## Open and build

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. If Android Studio asks to install SDK 35, install it.
4. Connect your Android phone with USB debugging enabled, or start an emulator.
5. Press Run.

To create an APK:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The debug APK will normally be under:
app/build/outputs/apk/debug/app-debug.apk

## Important

This is a WebView wrapper. The app displays the live website, so the phone needs an internet connection. Changes made to the Netlify website appear in the app without rebuilding the APK.
